"""Spec-local utility helpers."""
