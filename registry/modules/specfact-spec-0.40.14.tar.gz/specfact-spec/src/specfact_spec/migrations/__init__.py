"""Spec-bundle migration helpers."""
