"""Spec-bundle generators."""
