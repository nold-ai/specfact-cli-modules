"""Project-local validator helpers."""
