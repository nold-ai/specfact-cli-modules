"""Structured review findings and report models."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Literal

from beartype import beartype
from icontract import ensure
from pydantic import BaseModel, Field, field_validator, model_validator


VALID_CATEGORIES = (
    "clean_code",
    "security",
    "type_safety",
    "contracts",
    "testing",
    "style",
    "architecture",
    "tool_error",
    "naming",
    "kiss",
    "yagni",
    "dry",
    "solid",
    "ai_bloat",
)
VALID_SEVERITIES = ("error", "warning", "info")
GUIDANCE_KINDS = ("safe_mechanical", "needs_tests", "design_judgment", "preserve")
ACTION_STATUSES = ("recommended", "applied", "kept", "skipped", "failed")
PRESERVE_REASONS = (
    "contract_lambda",
    "protocol_member",
    "public_api",
    "compat_shim",
    "cli_callback",
    "domain_wrapper",
    "spec_linked",
    "load_bearing",
)
PASS = "PASS"
PASS_WITH_ADVISORY = "PASS_WITH_ADVISORY"
FAIL = "FAIL"


class EvidenceRef(BaseModel):
    """Structured representation of supplemental evidence reference."""

    path: str | None = Field(default=None, description="Stable file path reference.")
    start_line: int | None = Field(default=None, ge=1, description="Start line number (1-based).")
    end_line: int | None = Field(default=None, ge=1, description="End line number (1-based).")
    artifact_id: str | None = Field(default=None, description="Artifact identifier.")
    description: str | None = Field(default=None, description="Description of the evidence.")

    @field_validator("path", "artifact_id", "description")
    @classmethod
    def _validate_non_empty_if_present(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("value must not be empty if provided")
        return value

    @model_validator(mode="after")
    def _validate_invariants(self) -> EvidenceRef:
        # At least one locator must be present
        if self.path is None and self.artifact_id is None and self.start_line is None:
            raise ValueError("at least one locator (path, artifact_id, or start_line) must be provided")

        # If end_line is provided, start_line must be provided
        if self.end_line is not None and self.start_line is None:
            raise ValueError("start_line must be provided if end_line is present")

        # If both start_line and end_line are provided, end_line >= start_line
        if self.start_line is not None and self.end_line is not None and self.end_line < self.start_line:
            raise ValueError("end_line must be greater than or equal to start_line")

        return self


class SignalTraceEntry(BaseModel):
    """Deterministic source signal that contributed to a cleanup finding."""

    tool: str = Field(..., description="Tool or analysis layer that produced the signal.")
    source: str = Field(..., description="Stable signal or rule source identifier.")
    fired: bool = Field(..., description="Whether the signal fired for this finding.")
    score: float | None = Field(default=None, description="Optional normalized signal score.")
    value: str | int | float | bool | None = Field(default=None, description="Optional raw signal value.")
    evidence_refs: list[EvidenceRef] | None = Field(default=None, description="Evidence backing the signal.")
    explanation: str = Field(..., description="Short explanation of the signal.")

    @field_validator("tool", "source", "explanation")
    @classmethod
    def _validate_non_empty_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("value must not be empty")
        return value


class PreserveReasonEvidence(BaseModel):
    """Closed-taxonomy reason that prevents automatic cleanup."""

    reason: Literal[
        "contract_lambda",
        "protocol_member",
        "public_api",
        "compat_shim",
        "cli_callback",
        "domain_wrapper",
        "spec_linked",
        "load_bearing",
    ] = Field(..., description="Closed preserve-reason taxonomy value.")
    evidence_refs: list[EvidenceRef] = Field(..., min_length=1, description="Evidence for the preserve reason.")
    explanation: str = Field(..., description="Why this context must be preserved.")

    @field_validator("explanation")
    @classmethod
    def _validate_non_empty_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("value must not be empty")
        return value


class RemediationPacket(BaseModel):
    """Portable AI IDE handoff contract for one cleanup finding."""

    issue: str = Field(..., description="Plain-language issue description.")
    recommended_action: str = Field(..., description="Recommended cleanup action.")
    possible_keep_reason: str | None = Field(default=None, description="Why the code might need to stay.")
    safety_checks: list[str] = Field(..., min_length=1, description="Checks required before editing.")
    validation_plan: list[str] = Field(..., min_length=1, description="Validation steps after editing.")
    safe_to_autofix: bool = Field(..., description="Whether an agent may apply this automatically.")
    patch_forecast_refs: list[str] | None = Field(default=None, description="Patch preview references when present.")

    @field_validator("issue", "recommended_action", "possible_keep_reason")
    @classmethod
    def _validate_non_empty_text(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("value must not be empty")
        return value

    @field_validator("safety_checks", "validation_plan", "patch_forecast_refs")
    @classmethod
    def _validate_non_empty_entries(cls, value: list[str] | None) -> list[str] | None:
        if value is not None and any(not item.strip() for item in value):
            raise ValueError("entries must not be empty")
        return value


class ReviewedLoc(BaseModel):
    """Reviewed Python LOC split by production and tests."""

    production: int = Field(..., ge=0)
    tests: int = Field(..., ge=0)
    total: int = Field(..., ge=0)

    @model_validator(mode="after")
    def _validate_total_matches_parts(self) -> ReviewedLoc:
        if self.total != self.production + self.tests:
            raise ValueError("reviewed_loc.total must equal production + tests")
        return self


class DeletionEstimate(BaseModel):
    """Non-binding deletion-line range."""

    low: int = Field(..., ge=0)
    expected: int = Field(..., ge=0)
    high: int = Field(..., ge=0)

    @model_validator(mode="after")
    def _validate_ordering(self) -> DeletionEstimate:
        if not self.low <= self.expected <= self.high:
            raise ValueError("estimated_deletion_lines must satisfy low <= expected <= high")
        return self


class AiBloatIndex(BaseModel):
    """Normalized cleanup metrics per KLOC."""

    findings_per_kloc: float = Field(..., ge=0.0)
    weighted_bloat_points_per_kloc: float = Field(..., ge=0.0)
    cleanup_yield_loc_per_kloc: float = Field(..., ge=0.0)


class GuidanceKindForecast(BaseModel):
    """Forecast aggregate for one guidance kind."""

    count: int = Field(..., ge=0)
    estimated_deletion_lines: int = Field(..., ge=0)


class CleanupForecast(BaseModel):
    """Aggregate cleanup impact forecast for simplify-focused reviews."""

    reviewed_loc: ReviewedLoc
    estimated_deletion_lines: DeletionEstimate
    ai_bloat_index: AiBloatIndex
    by_guidance_kind: dict[str, GuidanceKindForecast] = Field(default_factory=dict)
    by_action_status: dict[str, int] = Field(default_factory=dict)
    preview_evidence_count: int = Field(default=0, ge=0)
    mutation_evidence_count: int = Field(default=0, ge=0)


class ReviewFinding(BaseModel):
    """Structured representation of a code-review finding."""

    category: Literal[
        "clean_code",
        "security",
        "type_safety",
        "contracts",
        "testing",
        "style",
        "architecture",
        "tool_error",
        "naming",
        "kiss",
        "yagni",
        "dry",
        "solid",
        "ai_bloat",
    ] = Field(..., description="Governed code-review category.")
    severity: Literal["error", "warning", "info"] = Field(..., description="Finding severity.")
    tool: str = Field(..., description="Originating tool name.")
    rule: str = Field(..., description="Originating rule identifier.")
    file: str = Field(..., description="Repository-relative file path.")
    line: int = Field(..., ge=1, description="1-based source line number.")
    message: str = Field(..., description="User-facing finding message.")
    fixable: bool = Field(default=False, description="Whether the finding can be automatically fixed.")
    evidence_refs: list[EvidenceRef] | None = Field(
        default=None,
        description="Optional supplemental references with stable file paths, line ranges, or artifact identifiers.",
    )
    confidence: Literal["low", "medium", "high"] | None = Field(
        default=None,
        description="Optional deterministic simplification confidence bucket.",
    )
    rewrite_hint: str | None = Field(default=None, description="Optional concise simplification guidance.")
    canonical_pattern: str | None = Field(default=None, description="Optional normalized simplification pattern label.")
    intent_key: str | None = Field(default=None, description="Optional stable duplicate-intent grouping key.")
    estimated_deletion_lines: int | None = Field(
        default=None,
        ge=0,
        description="Optional non-binding deletion estimate for simplification triage.",
    )
    related_locations: list[EvidenceRef] | None = Field(
        default=None,
        description="Optional related source locations for grouped simplification candidates.",
    )
    guidance_kind: Literal["safe_mechanical", "needs_tests", "design_judgment", "preserve"] | None = Field(
        default=None,
        description="Guided simplification action class.",
    )
    recommended_action: (
        Literal[
            "remove",
            "inline",
            "collapse",
            "deduplicate",
            "make_required",
            "keep",
            "inspect",
        ]
        | None
    ) = Field(default=None, description="Recommended simplification action.")
    clean_code_principle: (
        Literal[
            "kiss",
            "dry",
            "yagni",
            "contracts",
            "api_stability",
            "readability",
        ]
        | None
    ) = Field(default=None, description="Primary clean-code principle behind the recommendation.")
    rationale: str | None = Field(default=None, description="Why the recommendation is meaningful.")
    safety_checks: list[str] | None = Field(
        default=None,
        description="Concrete checks an agent or developer must satisfy before applying the change.",
    )
    preserve_reason: str | None = Field(
        default=None,
        description="Why a preserve recommendation should be kept despite apparent bloat.",
    )
    action_status: Literal["recommended", "applied", "kept", "skipped", "failed"] | None = Field(
        default=None,
        description="Lifecycle status for recommended simplification work.",
    )
    before_ref: EvidenceRef | None = Field(default=None, description="Evidence reference before an applied action.")
    after_ref: EvidenceRef | None = Field(default=None, description="Evidence reference after an applied action.")
    improvement: str | None = Field(default=None, description="Evidence-backed improvement summary.")
    signal_trace: list[SignalTraceEntry] | None = Field(
        default=None,
        description="Optional deterministic signal trace for cleanup findings.",
    )
    preserve_reasons: list[PreserveReasonEvidence] | None = Field(
        default=None,
        description="Optional closed-taxonomy preserve reasons that block automatic cleanup.",
    )
    remediation_packet: RemediationPacket | None = Field(
        default=None,
        description="Optional portable cleanup handoff packet for AI IDEs.",
    )

    @field_validator(
        "tool",
        "rule",
        "file",
        "message",
        "rewrite_hint",
        "canonical_pattern",
        "intent_key",
        "rationale",
        "preserve_reason",
        "improvement",
    )
    @classmethod
    def _validate_non_empty_text(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("value must not be empty")
        return value

    @field_validator("safety_checks")
    @classmethod
    def _validate_safety_checks(cls, value: list[str] | None) -> list[str] | None:
        if value is None:
            return value
        if not value:
            raise ValueError("safety_checks must not be empty when provided")
        if any(not item.strip() for item in value):
            raise ValueError("safety_checks entries must not be empty")
        return value

    @field_validator("signal_trace", "preserve_reasons")
    @classmethod
    def _validate_non_empty_evidence_list(cls, value: list[object] | None) -> list[object] | None:
        if value is not None and not value:
            raise ValueError("evidence lists must not be empty when provided")
        return value

    @model_validator(mode="after")
    def _validate_guided_metadata(self) -> ReviewFinding:
        guided_fields = (
            self.recommended_action,
            self.clean_code_principle,
            self.rationale,
            self.safety_checks,
            self.action_status,
            self.preserve_reason,
            self.before_ref,
            self.after_ref,
            self.improvement,
        )
        if self.guidance_kind is None:
            if any(value is not None for value in guided_fields):
                raise ValueError("guidance_kind is required when guided metadata fields are present")
            return self
        if self.recommended_action is None:
            raise ValueError("recommended_action is required when guidance_kind is present")
        if self.clean_code_principle is None:
            raise ValueError("clean_code_principle is required when guidance_kind is present")
        if self.rationale is None:
            raise ValueError("rationale is required when guidance_kind is present")
        if self.safety_checks is None:
            raise ValueError("safety_checks is required when guidance_kind is present")
        if self.guidance_kind == "preserve" and self.preserve_reason is None:
            raise ValueError("preserve_reason is required for preserve guidance")
        return self

    @beartype
    @ensure(lambda result: isinstance(result, bool))
    def has_simplification_metadata(self) -> bool:
        """Return whether this finding carries additive simplification metadata."""
        return any(
            value is not None
            for value in (
                self.confidence,
                self.rewrite_hint,
                self.canonical_pattern,
                self.intent_key,
                self.estimated_deletion_lines,
                self.related_locations,
                self.guidance_kind,
                self.recommended_action,
                self.clean_code_principle,
                self.rationale,
                self.safety_checks,
                self.preserve_reason,
                self.action_status,
                self.before_ref,
                self.after_ref,
                self.improvement,
                self.signal_trace,
                self.preserve_reasons,
                self.remediation_packet,
            )
        )

    @beartype
    @ensure(lambda result: isinstance(result, bool))
    def has_guided_simplification_metadata(self) -> bool:
        """Return whether this finding carries agent-action simplification metadata."""
        return self.guidance_kind is not None

    @beartype
    @ensure(lambda result: isinstance(result, bool))
    def is_safe_mechanical_simplification(self) -> bool:
        """Return whether the finding is an unresolved safe mechanical simplification."""
        return (
            self.guidance_kind == "safe_mechanical"
            and self.action_status in {None, "recommended", "failed"}
            and not self.preserve_reasons
        )

    @beartype
    @ensure(lambda result: isinstance(result, bool))
    def has_cleanup_handoff_metadata(self) -> bool:
        """Return whether this finding carries cleanup forecast or handoff metadata."""
        return self.signal_trace is not None or self.preserve_reasons is not None or self.remediation_packet is not None

    @beartype
    @ensure(lambda result: isinstance(result, bool))
    def simplification_metadata_is_deterministic(self) -> bool:
        """Return whether simplification metadata is concrete enough for queued rewrites."""
        return all(
            value is not None
            for value in (
                self.rewrite_hint,
                self.canonical_pattern,
                self.intent_key,
            )
        )

    @beartype
    @ensure(lambda self, result: result == (self.severity == "error" and not self.fixable))
    def is_blocking(self) -> bool:
        """Return whether this finding blocks a passing review verdict."""
        return self.severity == "error" and not self.fixable


class SimplificationSummary(BaseModel):
    """Aggregate evidence for guided simplification review runs."""

    by_guidance_kind: dict[str, int] = Field(default_factory=dict)
    by_action_status: dict[str, int] = Field(default_factory=dict)
    blocking_simplification_count: int = Field(default=0, ge=0)
    applied_count: int = Field(default=0, ge=0)
    kept_count: int = Field(default=0, ge=0)


class ReviewReport(BaseModel):
    """Governance-aligned evidence envelope for code review results."""

    schema_version: str = Field(default="1.0", description="Evidence schema version.")
    run_id: str = Field(..., description="Stable review run identifier.")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC), description="UTC timestamp for the run.")
    overall_verdict: Literal["PASS", "PASS_WITH_ADVISORY", "FAIL"] | None = Field(
        default=None,
        description="Governance-aligned overall verdict.",
    )
    ci_exit_code: Literal[0, 1] | None = Field(default=None, description="Exit code suitable for CI enforcement.")
    score: int = Field(..., ge=0, le=120, description="Review score in the inclusive range 0..120.")
    reward_delta: int | None = Field(default=None, description="Reward delta derived from score - 80.")
    findings: list[ReviewFinding] = Field(default_factory=list, description="Structured review findings.")
    summary: str = Field(..., description="Human-readable review summary.")
    simplification_summary: SimplificationSummary | None = Field(
        default=None,
        description="Aggregate simplification guidance and action-status evidence.",
    )
    cleanup_forecast: CleanupForecast | None = Field(
        default=None,
        description="Aggregate cleanup forecast for simplify-focused review runs.",
    )
    house_rules_updates: list[str] = Field(default_factory=list, description="Suggested house-rules updates.")

    @field_validator("schema_version", "run_id", "summary")
    @classmethod
    def _validate_non_empty_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("value must not be empty")
        return value

    @field_validator("timestamp")
    @classmethod
    def _normalize_timestamp(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC)

    @model_validator(mode="after")
    def _derive_governance_fields(self) -> ReviewReport:
        if self.simplification_summary is None:
            self.simplification_summary = _build_simplification_summary(self.findings)
        if self.cleanup_forecast is not None or any(
            finding.has_cleanup_handoff_metadata() for finding in self.findings
        ):
            self.schema_version = "1.3"
        elif self.simplification_summary is not None:
            self.schema_version = "1.2"
        elif any(finding.has_simplification_metadata() for finding in self.findings):
            self.schema_version = "1.1"
        blocking_error_present = any(finding.is_blocking() for finding in self.findings)
        self.reward_delta = self.score - 80
        if blocking_error_present:
            self.overall_verdict = FAIL
            self.ci_exit_code = 1
            return self
        if self.score >= 70:
            self.overall_verdict = PASS
            self.ci_exit_code = 0
            return self
        if self.score >= 50:
            self.overall_verdict = PASS_WITH_ADVISORY
            self.ci_exit_code = 0
            return self
        self.overall_verdict = FAIL
        self.ci_exit_code = 1
        return self

    @beartype
    @ensure(lambda result: isinstance(result, bool))
    def has_blocking_findings(self) -> bool:
        """Return whether the report contains any blocking findings."""
        return any(finding.is_blocking() for finding in self.findings)


def _build_simplification_summary(findings: list[ReviewFinding]) -> SimplificationSummary | None:
    guided = [finding for finding in findings if finding.has_guided_simplification_metadata()]
    if not guided:
        return None
    by_guidance_kind: dict[str, int] = {}
    by_action_status: dict[str, int] = {}
    for finding in guided:
        if finding.guidance_kind is not None:
            by_guidance_kind[finding.guidance_kind] = by_guidance_kind.get(finding.guidance_kind, 0) + 1
        if finding.action_status is not None:
            by_action_status[finding.action_status] = by_action_status.get(finding.action_status, 0) + 1
    return SimplificationSummary(
        by_guidance_kind=by_guidance_kind,
        by_action_status=by_action_status,
        blocking_simplification_count=sum(finding.is_safe_mechanical_simplification() for finding in guided),
        applied_count=by_action_status.get("applied", 0),
        kept_count=by_action_status.get("kept", 0),
    )
