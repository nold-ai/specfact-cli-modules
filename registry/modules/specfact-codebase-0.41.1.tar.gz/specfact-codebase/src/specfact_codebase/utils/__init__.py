"""Codebase-local utility helpers."""
