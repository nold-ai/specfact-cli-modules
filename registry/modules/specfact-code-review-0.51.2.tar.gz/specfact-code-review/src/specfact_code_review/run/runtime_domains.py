"""Record the exact dependency closure admitted to each target execution domain."""

from __future__ import annotations

import re
from importlib.metadata import Distribution, distributions
from pathlib import Path
from typing import Any

from icontract import ensure
from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name

from specfact_code_review.run.runtime_compatibility import MEMBER_DISTRIBUTIONS, analyzer_dependency_conflicts
from specfact_code_review.run.runtime_models import ProjectRuntimeError


_DOMAIN_ENTRIES = {
    "pylint": ("pylint",),
    "basedpyright": ("basedpyright",),
    "crosshair": ("crosshair-tool",),
    "pytest-observe": ("pytest", "pytest-cov"),
}
_PINNED = frozenset(name for _, names in MEMBER_DISTRIBUTIONS.values() for name in names)


def _runtime_module_name(filename: str) -> str:
    """Recognize Python payload names without using the supervisor's native ABI."""
    if filename.endswith((".py", ".pyc")):
        name = filename.rsplit(".", maxsplit=1)[0]
    elif filename.endswith((".so", ".pyd")):
        name, _, suffix = filename.partition(".")
        if suffix not in {"so", "pyd", "abi3.so", "abi3.pyd"} and not re.fullmatch(
            r"(?:cpython-\d+[a-z]*|cp\d+[a-z]*)-[\w-]+\.(?:so|pyd)", suffix
        ):
            return ""
    else:
        return ""
    return name if name.isidentifier() else ""


def _top_level_imports(distribution: Distribution) -> set[str]:
    """Bind ownership to present recorded modules, not stale build metadata."""
    files = distribution.files
    if files is None:
        raise ProjectRuntimeError(f"project_analyzer_import_inventory_missing:{distribution.metadata['Name']}")
    names = set()
    for entry in files:
        module = _runtime_module_name(entry.name)
        if not module or not all(part.isidentifier() for part in entry.parts[:-1]):
            continue
        if Path(str(distribution.locate_file(entry))).is_file():
            names.add(entry.parts[0] if len(entry.parts) > 1 else module)
    return names


def _dependency_names(
    requirements: list[str],
    environment: dict[str, str],
    *,
    domain: str,
    target: dict[str, Any],
    sealed: dict[str, Distribution],
) -> list[str]:
    names = []
    for raw in requirements:
        requirement = Requirement(raw)
        if requirement.marker is None or requirement.marker.evaluate(environment):
            name = str(canonicalize_name(requirement.name))
            selected = _selected_distribution(name, target, sealed)
            if selected is not None and not requirement.specifier.contains(selected[0]["version"], prereleases=True):
                raise ProjectRuntimeError(
                    f"project_analyzer_dependency_incompatible:{domain}:{name}; "
                    f"selected={selected[0]['version']}, required={requirement.specifier}"
                )
            names.append(name)
    return names


def _selected_distribution(
    name: str, target: dict[str, Any], sealed: dict[str, Distribution]
) -> tuple[dict[str, Any], list[str], set[str]] | None:
    if name in target and name not in _PINNED:
        project = target[name]
        return (
            {"name": name, "version": project["version"], "origin": "project"},
            project.get("requires_dist", []) or [],
            set(),
        )
    distribution = sealed.get(name)
    if distribution is None:
        return None
    return (
        {"name": name, "version": distribution.version, "origin": "analyzer"},
        list(distribution.requires or []),
        _top_level_imports(distribution),
    )


def _domain_graph(
    domain: str,
    target: dict[str, Any],
    sealed: dict[str, Distribution],
    environment: dict[str, str],
    *,
    entries: tuple[str, ...] | None = None,
) -> dict[str, Any]:
    pending = list(_DOMAIN_ENTRIES[domain] if entries is None else entries)
    visited = set()
    rows = []
    imports = set()
    while pending:
        name = pending.pop()
        if name in visited:
            continue
        visited.add(name)
        selected = _selected_distribution(name, target, sealed)
        if selected is None:
            raise ProjectRuntimeError(
                f"project_analyzer_dependency_missing:{domain}:{name}; "
                "rebuild the runtime with its complete declared dependencies"
            )
        row, requirements, admitted_imports = selected
        dependencies = _dependency_names(requirements, environment, domain=domain, target=target, sealed=sealed)
        rows.append({**row, "dependencies": sorted(dependencies)})
        imports.update(admitted_imports)
        pending.extend(dependencies)
    return {"installed": sorted(rows, key=lambda row: row["name"]), "sealed_imports": sorted(imports)}


@ensure(lambda result: set(result) == set(_DOMAIN_ENTRIES))
def member_dependency_graphs(inventory: dict[str, Any], analyzer_root: Path) -> dict[str, Any]:
    """Admit required analyzer packages without exposing unrelated sealed dependencies."""
    target = {
        str(canonicalize_name(row["metadata"]["name"])): row["metadata"] for row in inventory.get("installed", [])
    }
    sealed = {str(canonicalize_name(dist.metadata["Name"])): dist for dist in distributions(path=[str(analyzer_root)])}
    environment = {**default_environment(), **inventory.get("environment", {}), "extra": ""}
    return {domain: _domain_graph(domain, target, sealed, environment) for domain in _DOMAIN_ENTRIES}


@ensure(lambda result: set(result[0]) <= {"pylint", "crosshair", "pytest-observe"})
def native_member_dependency_graphs(
    inventory: dict[str, Any], analyzer_root: Path
) -> tuple[dict[str, Any], dict[str, str]]:
    """Bind native Python domains; Node BasedPyright has its own npm closure."""
    target = {
        str(canonicalize_name(row["metadata"]["name"])): row["metadata"] for row in inventory.get("installed", [])
    }
    sealed = {str(canonicalize_name(dist.metadata["Name"])): dist for dist in distributions(path=[str(analyzer_root)])}
    environment = {**default_environment(), **inventory.get("environment", {}), "extra": ""}
    entries = {name: values for name, values in _DOMAIN_ENTRIES.items() if name != "basedpyright"}
    graphs, conflicts = {}, analyzer_dependency_conflicts(inventory, analyzer_root)
    # Native BasedPyright is the sealed npm/Node distribution, not the Linux
    # Python distribution whose dependency chain includes nodejs-wheel binaries.
    conflicts.pop("basedpyright", None)
    for domain, names in entries.items():
        member = {"crosshair": "contracts", "pytest-observe": "targeted-pytest-coverage"}.get(domain, domain)
        if member in conflicts:
            continue
        try:
            graphs[domain] = _domain_graph(domain, target, sealed, environment, entries=names)
        except ProjectRuntimeError as exc:
            conflicts[member] = str(exc)
    return graphs, conflicts
