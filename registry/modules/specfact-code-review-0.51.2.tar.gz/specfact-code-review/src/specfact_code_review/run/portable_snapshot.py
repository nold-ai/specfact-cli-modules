"""Attach a validated local runtime to review without changing v1 PR authority."""

from __future__ import annotations

import json
import os
import shutil
import tempfile
from contextlib import ExitStack
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

from icontract import require

from specfact_code_review.run.portable_worker import (
    DEPENDENT_MEMBERS,
    contract_inputs,
    preparation_failure_snapshot,
    select_test_paths,
)
from specfact_code_review.run.runtime_artifacts import load_runtime
from specfact_code_review.run.runtime_builder import copy_project, prepare_runtime
from specfact_code_review.run.runtime_discovery import discover_project
from specfact_code_review.run.runtime_interpreter import project_worker
from specfact_code_review.run.runtime_models import ProjectPlan, ProjectRuntimeError, document_digest
from specfact_code_review.run.runtime_sources import verify_inputs
from specfact_code_review.run.runtime_vcs import vcs_context


@require(lambda root: root.is_dir())
def project_runtime_requested(root: Path, options: Any) -> bool:
    """Recognize declared project environments while preserving stdlib-only fixtures."""
    return bool(
        options.project_config
        or options.project_runtime
        or any(
            (root / name).exists()
            for name in (
                "pyproject.toml",
                "hatch.toml",
                "requirements.txt",
                "requirements.in",
                ".python-version",
                "pylock.toml",
                "setup.py",
                "setup.cfg",
                "uv.lock",
                "poetry.lock",
            )
        )
    )


@require(lambda root: root.is_dir())
def discover_snapshot(root: Path, *, config_path: Path | None, source_snapshot: Any = None) -> ProjectPlan:
    """Attach selected VCS metadata without changing the immutable source tree."""
    repository = getattr(source_snapshot, "repository", None)
    plan = discover_project(root, config_path=config_path, activation_root=repository)
    if repository is None:
        return plan
    commit = getattr(source_snapshot, "vcs_commit", "") or source_snapshot.commit
    if commit.startswith(("index:", "index-")):
        raise ProjectRuntimeError("project_index_vcs_commit_missing: recapture the review index")
    return replace(
        plan,
        vcs_repository=repository,
        vcs=vcs_context(repository, commit, tree=getattr(source_snapshot, "tree", None)),
    )


@dataclass(frozen=True)
class ProjectSnapshotRequest:
    """Source and selection context for one independently bound review side."""

    snapshot_root: Path
    files: list[Path]
    options: Any
    assurance_kind: str
    source_snapshot: Any = None


def _write_native_basedpyright_config(
    snapshot_root: Path, files: list[Path], config_root: Path, *, source_roots: tuple[str, ...] = ()
) -> Path:
    """Bind native imports to the sealed staged project runtime without spawning Python."""

    relative_files = {
        Path(os.path.abspath(snapshot_root / path)).relative_to(snapshot_root).as_posix() for path in files
    }
    if any(
        not isinstance(root, str)
        or Path(root).is_absolute()
        or ".." in Path(root).parts
        or not (snapshot_root / root).is_dir()
        or (snapshot_root / root).resolve() != snapshot_root / root
        for root in source_roots
    ):
        raise ProjectRuntimeError("project_native_basedpyright_source_root_invalid")
    values = {
        "extraPaths": ["../../.specfact-project-runtime/site-packages", *(f"../../{root}" for root in source_roots)],
        "include": [f"../../{relative}" for relative in sorted(relative_files)],
    }
    config = config_root / "basedpyright-native.json"
    config.write_text(
        json.dumps(values, ensure_ascii=False, separators=(",", ":"), sort_keys=True) + "\n",
        encoding="utf-8",
    )
    config.chmod(0o400)
    return config


def _write_native_contract_inventory(plan: ProjectPlan, config_root: Path) -> Path:
    """Bind large and empty native test inventories without widening launch budgets."""
    inputs = contract_inputs(plan)
    roots = list(inputs[2::2]) if inputs[0] == "contract-inputs-v1" else []
    payload = json.dumps({"schema": "contract-inputs-v2", "test_roots": roots}, separators=(",", ":")).encode()
    if len(payload) > 16 << 20:
        raise ProjectRuntimeError("project_contract_inventory_too_large")
    path = config_root / "contracts-native.json"
    path.write_bytes(payload)
    path.chmod(0o400)
    return path


@require(lambda request: request.snapshot_root.is_dir())
def run_project_snapshot(runtime: Any, request: ProjectSnapshotRequest) -> tuple[Any, dict[str, Any]]:
    """Bind every review side to its selected signed Python worker."""
    snapshot_root, files, options = request.snapshot_root, request.files, request.options
    source_snapshot = request.source_snapshot
    try:
        plan = discover_snapshot(snapshot_root, config_path=options.project_config, source_snapshot=source_snapshot)
        with project_worker(runtime, plan) as selected:
            return _run_project_snapshot(selected, request, plan)
    except (OSError, ValueError) as exc:
        return _failed_project_snapshot(
            runtime, snapshot_root=snapshot_root, files=files, options=options, reason=str(exc)
        )


def _failed_project_snapshot(
    runtime: Any, *, snapshot_root: Path, files: list[Path], options: Any, reason: str
) -> tuple[Any, dict[str, Any]]:
    from specfact_code_review.run.runner import CapsuleSnapshotSettings

    unavailable = preparation_failure_snapshot(reason)
    request = ProjectSnapshotRequest(snapshot_root, files, options, "explicit_files")
    try:
        snapshot = _run_in_private_source(
            runtime, request, CapsuleSnapshotSettings(portable_runtime=True, unavailable_members=unavailable)
        )
    except (OSError, ValueError) as exc:
        reason = f"project_source_copy_failed:{exc}; preparation={reason}"
        snapshot = _blocked_source_snapshot(runtime, options, reason)
    return snapshot, {
        "status": "UNKNOWN",
        "diagnostic": reason,
        "remedy": (
            "Inspect project configuration with specfact code review runtime inspect --json, then run runtime prepare."
        ),
    }


def _blocked_source_snapshot(runtime: Any, options: Any, reason: str) -> Any:
    """Record incomplete evidence without exposing an unsafe original source mount."""
    from specfact_code_review.run.runner import (
        CapsuleSnapshotSettings,
        _run_capsule_snapshot,
        default_pr_range_profile,
    )

    blocked: dict[str, dict[str, object]] = {
        member: {"execution_state": "error", "evidence_outcome": "UNKNOWN", "diagnostic": reason}
        for member in default_pr_range_profile().all_ids
    }
    with tempfile.TemporaryDirectory(prefix="specfact-unavailable-source-") as directory:
        return _run_capsule_snapshot(
            runtime,
            snapshot_root=Path(directory),
            files=[],
            options=options,
            settings=CapsuleSnapshotSettings(portable_runtime=True, unavailable_members=blocked),
        )


def _run_in_private_source(runtime: Any, request: ProjectSnapshotRequest, settings: Any) -> Any:
    """Keep excluded host files out of every portable analyzer's source mount."""
    from specfact_code_review.run.runner import _run_capsule_snapshot

    with tempfile.TemporaryDirectory(prefix="specfact-project-source-") as directory:
        source = Path(directory).resolve(strict=True) / "source"
        copy_project(request.snapshot_root, source, include_vcs=False)
        files = [
            source / Path(os.path.abspath(request.snapshot_root / path)).relative_to(request.snapshot_root)
            for path in request.files
        ]
        return _run_capsule_snapshot(
            runtime, snapshot_root=source, files=files, options=request.options, settings=settings
        )


@require(lambda request: request.snapshot_root.is_dir())
def _run_project_snapshot(
    runtime: Any, request: ProjectSnapshotRequest, plan: ProjectPlan
) -> tuple[Any, dict[str, Any]]:
    """Prepare once, execute applicable members, and retain independent evidence."""
    from specfact_code_review.run.runner import (
        CapsuleSnapshotSettings,
        _bind_pytest_coverage_policy,
        _PolicyBindingBuilder,
        _with_pytest_inventory,
    )

    snapshot_root, files, options = request.snapshot_root, request.files, request.options
    assurance_kind = request.assurance_kind
    try:
        prepared = (
            load_runtime(
                options.project_runtime,
                plan=plan,
                environment_id=runtime.environment_id,
                worker_identity=runtime.identity,
            )
            if options.project_runtime
            else prepare_runtime(plan, runtime=runtime)
        )
    except (OSError, ValueError) as exc:
        return _failed_project_snapshot(
            runtime, snapshot_root=snapshot_root, files=files, options=options, reason=str(exc)
        )
    evidence = {
        "status": "PASS",
        "schema": "project-runtime-layer-v2",
        "identity": prepared.identity,
        "project_identity": plan.identity,
        "environment_id": runtime.environment_id,
        "authority": "local_build",
        "protected_pr_eligible": False,
        "source_roots": list(plan.source_roots),
    }
    arguments: dict[str, tuple[str, ...]] = {}
    conflicts = prepared.descriptor.get("inventory", {}).get("analyzer_conflicts", {})
    unavailable = {
        member: {"execution_state": "error", "evidence_outcome": "UNKNOWN", "diagnostic": reason}
        for member, reason in conflicts.items()
    }
    native_backend = getattr(runtime, "backend", "linux-x86_64") == "darwin-arm64"
    native_test_selectors: tuple[str, ...] = ()
    native_test_selection_complete = False
    if not options.no_tests:
        try:
            native_test_selectors = tuple(select_test_paths(plan, files, full=assurance_kind == "full"))
            native_test_selection_complete = True
            if not native_backend:
                arguments["targeted-pytest-coverage"] = (
                    "portable-pytest-v2",
                    json.dumps({"selectors": native_test_selectors}),
                )
        except ProjectRuntimeError as exc:
            unavailable["targeted-pytest-coverage"] = {
                "execution_state": "error",
                "evidence_outcome": "UNKNOWN",
                "diagnostic": str(exc),
            }
    bound = replace(
        runtime, identity=document_digest({"capsule": runtime.identity, "project_runtime": prepared.identity})
    )
    with ExitStack() as cleanup:
        config_roots: tuple[Path, ...] = ()
        if native_backend:
            if native_test_selection_complete:
                builder = _PolicyBindingBuilder()
                try:
                    _bind_pytest_coverage_policy(builder, snapshot_root, local_project_assurance=assurance_kind)
                    pytest_bindings = _with_pytest_inventory(builder.result(), native_test_selectors)
                    config_roots = pytest_bindings.config_roots
                    arguments.update(pytest_bindings.member_argv)
                except (OSError, TypeError, ValueError) as exc:
                    unavailable["targeted-pytest-coverage"] = {
                        "execution_state": "error",
                        "evidence_outcome": "UNKNOWN",
                        "diagnostic": f"native_pytest_policy_projection_failed:{exc}",
                    }
                finally:
                    for root in dict.fromkeys(builder.cleanup_roots):
                        cleanup.callback(shutil.rmtree, root, ignore_errors=True)
            temporary_parent = Path(tempfile.gettempdir()).resolve(strict=True)
            directory = cleanup.enter_context(
                tempfile.TemporaryDirectory(prefix="specfact-native-basedpyright-", dir=temporary_parent)
            )
            config_root = Path(directory).resolve(strict=True)
            roots = prepared.descriptor.get("inventory", {}).get("source_roots", [])
            if not isinstance(roots, list):
                raise ProjectRuntimeError("project_native_basedpyright_source_root_invalid")
            config = _write_native_basedpyright_config(snapshot_root, files, config_root, source_roots=tuple(roots))
            config_roots = (*config_roots, config_root)
            contract_config = _write_native_contract_inventory(plan, config_root)
            arguments["contracts"] = (
                "contract-inputs-v2",
                f"/opt/specfact/config/{len(config_roots)}/{contract_config.name}",
            )
            arguments["basedpyright"] = (
                "--project",
                f"/opt/specfact/config/{len(config_roots)}/{config.name}",
            )
        else:
            arguments["basedpyright"] = ("--pythonpath", "/opt/specfact/project-runtime/bin/python")
        snapshot = _run_in_private_source(
            bound,
            request,
            CapsuleSnapshotSettings(
                config_roots=config_roots,
                project_runtime_root=prepared.root,
                member_argv=arguments,
                portable_runtime=not native_backend,
                unavailable_members=unavailable,
            ),
        )
    try:
        verify_inputs(plan)
        load_runtime(
            prepared.descriptor_path, plan=plan, environment_id=runtime.environment_id, worker_identity=runtime.identity
        )
    except ProjectRuntimeError as exc:
        for member in DEPENDENT_MEMBERS:
            snapshot.evidence[member].update(execution_state="error", evidence_outcome="UNKNOWN", diagnostic=str(exc))
        evidence.update(status="UNKNOWN", diagnostic=str(exc))
    return snapshot, evidence


@require(lambda scope_evidence: scope_evidence.get("assurance_kind") != "pr_range")
def run_project_scope_pair(resolution: Any, *, runtime: Any, options: Any, scope_evidence: dict[str, Any]) -> Any:
    """Resolve each immutable side separately; local provenance cannot authorize a PR."""
    from specfact_code_review.run.runner import _capsule_report, _classify_range_findings, _snapshot_python_files

    snapshots = (resolution.base_snapshot, resolution.head_snapshot)
    metadata_only = bool(resolution.selected_paths) and not any(
        Path(path).suffix in {".py", ".pyi"} for path in resolution.selected_paths
    )
    results = []
    bindings = {}
    for side, snapshot in zip(("base", "head"), snapshots, strict=True):
        side_options = replace(options, project_runtime=None) if side == "base" else options
        files = _snapshot_python_files(snapshot, resolution)
        if metadata_only:
            files = [snapshot.root / path for path in sorted(snapshot.contents) if Path(path).suffix in {".py", ".pyi"}]
        result, binding = run_project_snapshot(
            runtime,
            ProjectSnapshotRequest(
                snapshot_root=snapshot.root,
                source_snapshot=snapshot,
                files=files,
                options=side_options,
                assurance_kind="index" if scope_evidence.get("assurance_kind") == "index" else "range_preview",
            ),
        )
        results.append(result)
        bindings[side] = binding
    combined, findings = _classify_range_findings(resolution, results[0], results[1])
    native_versions = results[1].expected_versions
    native_platform = results[1].platform_id
    if results[0].expected_versions != native_versions or results[0].platform_id != native_platform:
        combined = {
            member: {
                **value,
                "execution_state": "error",
                "evidence_outcome": "UNKNOWN",
                "diagnostic": "project_range_runtime_identity_mismatch",
            }
            for member, value in combined.items()
        }
    evidence = {**scope_evidence, "project_runtime": bindings, "protected_pr_eligible": False}
    if evidence.get("assurance_kind") in {"range_candidate", "pr_range"}:
        evidence["assurance_kind"] = "range_preview"
    return _capsule_report(
        combined,
        findings,
        options=options,
        scope_evidence=evidence,
        expected_versions=native_versions,
        platform_id=native_platform,
    )
